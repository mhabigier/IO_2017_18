package ch.makery.shop.view;

import ch.makery.shop.model.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import ch.makery.shop.MainApp;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class TaskOverviewController {
    @FXML
    private TableView<Task> taskTable;
    @FXML
    private TableColumn<Task, String> titleColumn;
    @FXML
    private TableColumn<Task, String> authorColumn;

    @FXML
    private Label titleLabel;
    @FXML
    private Label authorLabel;
    @FXML
    private Label descriptionLabel;
    @FXML
    private Label priorityLabel;
    @FXML
    private Label dueDateLabel;
    @FXML
    private Label statusLabel;

    // Reference to the main application.
    private MainApp mainApp;

    /**
     * The constructor.
     * The constructor is called before the initialize() method.
     */
    public TaskOverviewController() {
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        // Initialize the book table with the two columns.
        titleColumn.setCellValueFactory(
                cellData -> cellData.getValue().titleProperty());
        authorColumn.setCellValueFactory(
                cellData -> cellData.getValue().authorProperty());

        // Clear book details.
        showBookDetails(null);

        // Listen for selection changes and show the book details when changed.
        taskTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showBookDetails(newValue));
    }

    /**
     * Is called by the main application to give a reference back to itself.
     *
     * @param mainApp
     */
    public void setMainApp(MainApp mainApp) {
        this.mainApp = mainApp;

        // Add observable list data to the table
        taskTable.setItems(mainApp.getTaskData());
    }

    private void showBookDetails(Task book) {
        if (book != null) {
            // Fill the labels with info from the person object.
            titleLabel.setText(book.getTitle());
            authorLabel.setText(book.getAuthor());
            descriptionLabel.setText(book.getDescription());
            dueDateLabel.setText(Integer.toString(book.getDueDate()));
            statusLabel.setText(book.isFinished2());
            priorityLabel.setText(book.getSubject2());
        } else {
            // Person is null, remove all the text.
            titleLabel.setText("");
            authorLabel.setText("");
            descriptionLabel.setText("");
            priorityLabel.setText("");
            dueDateLabel.setText("");
            statusLabel.setText("");
        }
    }

    /**
     * Called when the user clicks on the delete button.
     */
    @FXML
    private void handleDeleteBook() {
        int selectedIndex = taskTable.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            taskTable.getItems().remove(selectedIndex);
        } else {
            // Nothing selected.
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Book Selected");
            alert.setContentText("Please select a book in the table.");

            alert.showAndWait();
        }
    }

    /**
     * Called when the user clicks the new button. Opens a dialog to edit
     * details for a new person.
     */
    @FXML
    private void handleNewBook() {
        Task tempBook = new Task();
        boolean okClicked = mainApp.showTaskEditDialog(tempBook);
        if (okClicked) {
            mainApp.getTaskData().add(tempBook);
        }
    }

    /**
     * Called when the user clicks the edit button. Opens a dialog to edit
     * details for the selected person.
     */
    @FXML
    private void handleEditBook() {
        Task selectedBook = taskTable.getSelectionModel().getSelectedItem();
        if (selectedBook != null) {
            boolean okClicked = mainApp.showTaskEditDialog(selectedBook);
            if (okClicked) {
                showBookDetails(selectedBook);
            }

        } else {
            // Nothing selected.
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(mainApp.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Selection");
            alert.setContentText("Please select a book in the table.");

            alert.showAndWait();
        }
    }
}